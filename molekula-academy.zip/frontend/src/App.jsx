import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import AppShell from './components/AppShell';
import CoursesPage from './pages/CoursesPage';
import CourseDetailPage from './pages/CourseDetailPage';
import LessonPage from './pages/LessonPage';
import QuizPage from './pages/QuizPage';
import DashboardPage from './pages/DashboardPage';
import LoginPage from './pages/LoginPage';
import { isAuthenticated } from './api/client';

function RequireAuth({ children }) {
  if (!isAuthenticated()) return <Navigate to="/login" replace />;
  return <AppShell>{children}</AppShell>;
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Navigate to="/courses" replace />} />
        <Route path="/login" element={<LoginPage />} />

        {/* Authenticated — wrapped in AppShell */}
        <Route path="/courses"           element={<RequireAuth><CoursesPage /></RequireAuth>} />
        <Route path="/courses/:courseId" element={<RequireAuth><CourseDetailPage /></RequireAuth>} />
        <Route path="/courses/:courseId/topics/:topicId/lessons/:lessonId" element={<RequireAuth><LessonPage /></RequireAuth>} />

        <Route path="/quizzes/:quizId" element={<RequireAuth><QuizPage /></RequireAuth>} />

        {/* Stubs — pages to be built */}
        <Route path="/dashboard"  element={<RequireAuth><DashboardPage /></RequireAuth>} />
        <Route path="/progress"   element={<RequireAuth><Stub title="Napredak" /></RequireAuth>} />
        <Route path="/quizzes"    element={<RequireAuth><Stub title="Kvizovi" /></RequireAuth>} />
        <Route path="/schedule"   element={<RequireAuth><Stub title="Raspored" /></RequireAuth>} />
        <Route path="/messages"   element={<RequireAuth><Stub title="Poruke" /></RequireAuth>} />
        <Route path="/settings"   element={<RequireAuth><Stub title="Postavke" /></RequireAuth>} />
      </Routes>
    </BrowserRouter>
  );
}

// Temporary placeholder for pages not yet built
function Stub({ title }) {
  return (
    <div style={{ padding: 40, textAlign: 'center', color: 'var(--ink-soft)' }}>
      <p style={{ fontFamily: 'var(--mono)', fontSize: 12, letterSpacing: '.1em', textTransform: 'uppercase', color: 'var(--accent)', marginBottom: 16 }}>
        U izradi · Coming soon
      </p>
      <h1 style={{ fontFamily: 'var(--display)', fontSize: 36, color: 'var(--ink)', margin: '0 0 12px' }}>{title}</h1>
      <p style={{ fontSize: 16 }}>Ova stranica je još u izradi.</p>
    </div>
  );
}
