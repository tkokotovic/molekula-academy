const express = require('express');
const db = require('../db');
const { requireTeacher, requireOwner } = require('../middleware/auth');

const router = express.Router();

// Health check for teacher access — used in tests and future admin panel
router.get('/ping', requireTeacher, (req, res) => {
  res.json({ status: 'ok', user: req.user });
});

// ─── Owner-only routes ────────────────────────────────────────────────────────

// PATCH /api/admin/users/:id/subscription — set student subscription tier
router.patch('/users/:id/subscription', requireOwner, (req, res) => {
  const { subscription_tier } = req.body;

  if (!['basic', 'premium'].includes(subscription_tier)) {
    return res.status(400).json({ error: "subscription_tier mora biti 'basic' ili 'premium'." });
  }

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Korisnik nije pronađen.' });

  db.prepare('UPDATE users SET subscription_tier = ? WHERE id = ?')
    .run(subscription_tier, user.id);

  const updated = db.prepare(
    'SELECT id, name, email, role, subscription_tier, created_at FROM users WHERE id = ?'
  ).get(user.id);

  return res.json({ user: updated });
});

module.exports = router;
